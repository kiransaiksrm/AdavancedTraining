package bookdeatails;

public class Book {
  private String booktitle;
  private double bookprice;
 
  public String getBooktitle() {
		return booktitle;
	}
	public void setBooktitle(String booktitle) {
		this.booktitle = booktitle;
	}
	public double getBookprice() {
		return bookprice;
	}
	public void setBookprice(double price) {
		this.bookprice = price;
	}


}
