package bookdeatails;
import java.util.Scanner;
public class bookdetails
{
	 public static void main (String[] args) {
	        Scanner sc=new Scanner(System.in);
	        
	        System.out.println("Enter the Book name:");
	        String bookname=sc.nextLine();
	        
	        System.out.println("Enter the price:");
	        double price=sc.nextDouble();
	        sc.nextLine();
	        System.out.println("Enter the Book name:");
	        String bookname1=sc.nextLine();
	        
	        System.out.println("Enter the price:");
	        double price1=sc.nextDouble();
	        sc.nextLine();
	        
	        
	        Book b=new Book();
	        b.setBooktitle(bookname);
	        b.setBookprice(price);
	        System.out.println("Book Details");
	        System.out.println("Book Name :"+b.getBooktitle());
	        System.out.println("Book Price :"+b.getBookprice());
	        Book b1=new Book();
	        b.setBooktitle(bookname1);
	        b.setBookprice(price1);
	        System.out.println("Book Details");
	        System.out.println("Book Name :"+b.getBooktitle());
	        System.out.println("Book Price :"+b.getBookprice());
	       


    }
}



