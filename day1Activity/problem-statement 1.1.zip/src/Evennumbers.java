import java.util.Scanner;
public class Evennumbers {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number to find the even numbers:");
	    int input=sc.nextInt();
	    for(int i=1;i<=input;i++) {
	    	if(i%2==0) {
	    		System.out.println(i);
	    	}
	    }
	}
}
