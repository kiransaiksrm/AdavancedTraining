
public class Testclass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Rectangle r1 = new Rectangle();
        r1.inputuser();
        r1.areaRectangle();
        r1.parameterRectangle();
        r1.display();
        System.out.println("second rectangle");
        Rectangle r21 = new Rectangle();
        r21.inputuser();
        r21.areaRectangle();
        r21.parameterRectangle();
        r21.display();
        System.out.println("third rectangle::");
        Rectangle r31 = new Rectangle();
        r31.inputuser();
        r31.areaRectangle();
        r31.parameterRectangle();
        r31.display();
        System.out.println("fourth rectangle ::");
        Rectangle r41 = new Rectangle();
        r41.inputuser();
        r41.areaRectangle();
        r41.parameterRectangle();
        r41.display();
        System.out.println("fith rectangle:::");
        Rectangle r5 = new Rectangle();
        r5.inputuser();
        r5.areaRectangle();
        r5.parameterRectangle();
        r5.display();
    	
	}
}
