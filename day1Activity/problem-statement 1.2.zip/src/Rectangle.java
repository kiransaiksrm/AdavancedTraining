import java.util.Scanner;

public class Rectangle {
    int length;
    int breadth;
    int area;
	Rectangle(){
		length=0;
		breadth=0;
		
	}
	void userinput() {
        Scanner sc = new Scanner(System.in);
        System.out.print("Enter length of rectangle: ");
        length = sc.nextInt();
        System.out.print("Enter breadth of rectangle: ");
        breadth = sc.nextInt();
    }
	void Area() {
		area=length*breadth;
		System.out.println("Area of rectangle is:"+area);
	}
}
