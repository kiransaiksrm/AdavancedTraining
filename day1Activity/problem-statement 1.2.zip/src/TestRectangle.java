import java.util.Scanner;

public class TestRectangle {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("ENTER VALUES FOR FIRST RECTANGLE:");
		Rectangle r1 = new Rectangle();
        r1.userinput();
        r1.Area();
        System.out.println("ENTER VALUES FOR SECOND RECTANGLE:");
        Rectangle r2 = new Rectangle();
        r2.userinput();
        r2.Area();
        System.out.println("ENTER VALUES THIRD RECTANGLE:");
        Rectangle r3 = new Rectangle();
        r3.userinput();
        r3.Area();
        System.out.println("ENTER VALUES FOR FOURTH RECTANGLE:");
        Rectangle r4 = new Rectangle();
        r4.userinput();
        r4.Area();
        System.out.println("ENTER VALUES FOR FIVITH RECTANGLE:");
        Rectangle r5 = new Rectangle();
        r5.userinput();
        r5.Area();
	}

}
